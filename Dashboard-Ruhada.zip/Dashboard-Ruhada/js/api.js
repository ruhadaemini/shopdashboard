$.getJSON('https://api.unsplash.com/users/brianhaferkamp/likes/?client_id=9da242ad85084ad7ca951738b8e7d9478fd637ba6d41cf835be09e7e1628c9dc', function(data) {
  console.log(data);
  
  $.each(data, function(index, value) {
    console.log(value);
    
    var name = value.user.name;
    var bio = value.user.bio;
    var imageURL = value.urls.regular;
    
    // $('.name').text(name);
    // $('.bio').text(bio);
    // $('.image img').attr('src', imageURL);
    
    $('.output').append('<h1 class="name">' + name + '</h1><h2 class="bio">' + bio + '</h2><div class="image"><img src="' + imageURL + '"/></div>');
  });
});

$( document ).ready(function() {
  var api_url = 'https://api.unsplash.com/users/brianhaferkamp/likes/'
  var key = '5b578yg9yvi8sogirbvegoiufg9v9g579gviuiub8' // not real

  $( ".content a" ).each(function( index, element ) {
    $.ajax({
        url: api_url + "?client_id=" + key + "/" + $( this ).text(),
        contentType: "application/json",
        dataType: 'json',
        success: function(result){
            $( element ).after(
            '<a href="' + result.url + '"> \n ' +
              '<div class="link-preview"> \n ' +
                '<div class="preview-image" style="background-image:url(' + result.image + ');"></div> \n ' +
                '<div style="width:70%;" class="link-info"> \n ' +
                  '<h4>' + result.title +'</h4> \n ' +
                  '<p>' + result.description +'</p> \n ' +
                '</div><br> \n ' +
                  '<a href="' + result.url + '" class="url-info"><i class="far fa-link"></i>' + result.url + '</a> \n ' +
                '</div></a>');
            $( element ).remove();
        }
    })
  });
});