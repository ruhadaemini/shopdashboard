$.getJSON('http://us-central1-test-b7665.cloudfunctions.net/api/stores/ijpxNJLM732vm8AeajMR/products', function(data) {
  console.log(data);
  
  $.each(data, function(index, value) {
    console.log(value);

    [
      {
        "title": "string",
        "category": "string",
        "price": 0,
        "employee": "string",
        "description": "string"
      }
    ]
    var id = value.id;
    var title = value.data.title;
    var description = value.data.description;
    var price = value.data.price;
    var category = value.data.category;
    var employee = value.data.employee;
    var reviews = value.data.reviews;
    
    
    $('.test').append('<div class="content-box"><h2 class="title"> <b>Title:</b> </br> ' + title + '</h2> <h2 class="description"> <b>Description:</b> </br>  ' + description + 
      '</h2> <h2 class="price"> <b>Price:</b> </br> ' + price + '</h2> <h2 class="category"> <b>Category:</b> </br> ' + category + '</h2> <h2 class="employee"> <b>Employee:</b> </br>' + employee + 
      '</h2> <h2 class="reviews"> <b>Reviews:</b> </br> ' + reviews + '</h2> <div class="action-btn-layout"><button class="deleteItem">Delete</button></div></div>');

    $('.product-title').append('<h2 class="title">' + title + '</h2>');
    $('.product-description').append('<h2 class="description">' + description + '</h2>');
    $('.product-price').append('<h2 class="price">' + price + '</h2>');
    $('.product-category').append('<h2 class="category">' + category + '</h2>');
    $('.product-employee').append('<h2 class="employee">' + employee + '</h2>');
    $('.product-reviews').append('<h2 class="reviews">' + reviews + '</h2>');
    $('.actions').append('<div class="action-btn-grid"><button class="deleteItem">Delete</button></div>');

    $(".deleteItem").click(function () { 
      $.ajax({
            url: 'http://us-central1-test-b7665.cloudfunctions.net/api/stores/ijpxNJLM732vm8AeajMR/products' + '/' + id,
            method: 'DELETE',
            contentType: 'application/json',
            success: function(response) {
                console.log(response);
                location.reload();
            }
        });
    }); 

  });
});


