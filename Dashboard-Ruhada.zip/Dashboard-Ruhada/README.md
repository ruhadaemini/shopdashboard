# Backoffice App

The backoffice app is dedicated to online shop’s employees, where they can create, display and delete products. Project is created with pure HTML, CSS and jQuery.

## Getting Started

To start the application you just need to open index.html file

## Authors

* **Ruhada Emini** 

## Acknowledgments
